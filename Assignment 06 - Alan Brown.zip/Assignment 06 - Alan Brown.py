#-------------------------------------------------#
# Title: Working with Classes and Functions
# Dev:   Alan Brown
# Date:  5/15/2017
# ChangeLog: (Who, When, What)
#
#-------------------------------------------------#

#-- Data --#
# declare variables and constants
lstToDoList = []
fltSelection = 0
intRemove = 0
strNewValue = ""
strNewKey = ""

#-- Processing --#
class ToDoList(object):
    @staticmethod
    def LoadData():
        # Step 1
        # When the program starts, load the any data you have
        # in a text file called ToDo.txt into a python Dictionary.
        objFile = open("ToDo.txt", "r")
        lstTable = []
        for line in objFile:
            (key, val) = line.strip().split(",")
            lstTable.append({key: val.strip()})
        objFile.close
        return lstTable

    @staticmethod
    def DisplayMenu():
        # Step 2
        # Display a menu of choices to the user
        print("""
            Menu of Options
            1) Show current data
            2) Add a new item.
            3) Remove an existing item.
            4) Save Data to File
            5) Exit Program
            """)
        print()

    @staticmethod
    def DisplayData():
        # Step 3
        # Display all todo items to user
        print(lstToDoList)

    @staticmethod
    def AddItem(x1, x2):
        # Step 4
        # Add a new item to the list/Table
        lstToDoList.append({x1: x2})

    @staticmethod
    def RemoveItem(x1):
        # Step 5
        # Remove a new item to the list/Table
        del lstToDoList[x1]

    @staticmethod
    def SaveTasks(List):
        # Step 6
        # Save tasks to the ToDo.txt file
        objFile = open("ToDo.txt", "w")
        for item in List:
            for key, value in item.items():
                objFile.write("{}, {}\n".format(key, value))
        objFile.close()

#-- Input/Output --#

lstToDoList = ToDoList.LoadData()

while(True):
    ToDoList.DisplayMenu()
    fltSelection = float(input("Which option would you like to perform? [1 to 5] - "))
    print("\n")

    if fltSelection == 1:
        print("The current To Do List is: ")
        ToDoList.DisplayData()
        continue
    elif fltSelection == 2:
        strNewKey = str(input("Please enter a new To Do task. "))
        strNewValue = str(input("Please enter a the priority level for this task. "))
        ToDoList.AddItem(strNewKey, strNewValue)
        continue
    elif fltSelection == 3:
        intRemove = int(input("Please enter the index number of the item you "
                              "would like to remove from the list."))
        while intRemove >= len(lstToDoList):
            intRemove = int(input("List index is out of range. Enter a valid index number"))

        ToDoList.RemoveItem(intRemove)
        continue
    elif fltSelection == 4:
        ToDoList.SaveTasks(lstToDoList)
        print("The To Do List has been saved.")
        continue
    elif fltSelection == 5:
        break
