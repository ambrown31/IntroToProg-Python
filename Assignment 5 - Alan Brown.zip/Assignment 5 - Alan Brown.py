#-------------------------------------------------#
# Title: Working with Dictionaries
# Dev:   Alan Brown
# Date:  5/8/2017
# ChangeLog: (Who, When, What)
#   RRoot, 11/02/2016, Created starting template
#   Alan Brown, 5/8/2017, Added code to complete assignment 5
#https://www.tutorialspoint.com/python/python_dictionary.htm
#-------------------------------------------------#

#-- Data --#
# declare variables and constants
dictNewRow = {}
lstTable = []
strChoice = ""
strNewValue = ""
strNewKey = ""

#-- Input/Output -- (These steps are combined for this script)-- Processing --#
# User can see a Menu (Step 2)
# User can see data (Step 3)
# User can insert or delete data(Step 4 and 5)
# User can save to file (Step 6)

# Step 1
# When the program starts, load the any data you have
# in a text file called ToDo.txt into a python Dictionary.
objFile = open("ToDo.txt", "r")
for line in objFile:
    line = line.strip()
    (key, val) = line.split(",")
    val = val.strip()
    dictRow = {}
    dictRow[key] = val
    lstTable.append(dictRow)
objFile.close
print("The list of data from the 'ToDo.txt' file is: ", lstTable)

# Step 2 - Display a menu of choices to the user

while(True):
    print ("""
    Menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File
    5) Exit Program
    """)
    strChoice = str(input("Which option would you like to perform? [1 to 4] - "))
    print()#adding a new line

    # Step 3 -Show the current items in the table
    if (strChoice.strip() == '1'):
        print("The current list of data is: ", lstTable)
        continue
    # Step 4 - Add a new item to the list/Table
    elif(strChoice.strip() == '2'):
        strNewKey = str(input("Please enter a new To Do task. "))
        strNewValue = str(input("Please enter a the priority level for this task. "))
        dictNewRow[strNewKey] = strNewValue
        lstTable.append(dictNewRow)
        continue
    # Step 5 - Remove a new item to the list/Table
    elif(strChoice == '3'):
        intRemove = int(input("Please enter the index number of the item you "
                              "would like to remove from the list."))
        del lstTable[intRemove]
        continue
    # Step 6 - Save tasks to the ToDo.txt file
    elif(strChoice == '4'):
        objFile = open("ToDo.txt", "w")
        for item in lstTable:
            item = str(item)
            for char in item:
                if char in "{'}":
                    item = item.replace(char, '')
            for char in item:
                if char == ":":
                    item = item.replace(char, ',')
            objFile.write(item + "\n")
        continue
        objFile.close
    # Step 7 - Exit the program
    elif (strChoice == '5'):
        break #and Exit the program

#-------------------------------
